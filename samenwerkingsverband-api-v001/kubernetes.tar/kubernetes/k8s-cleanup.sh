#!/bin/bash
#
# Script to cleanup resource generated in development environment

if [ $# -ne 4 ]; then
  echo "Usage: $0 <project-name> <branch> <namespace> <kube-config-file>"
fi

PROJECT=$1
BRANCH=$2
NAMESPACE=$3
KUBE_CONFIG=$4

BKWI_SERVICE_NAME=$(echo "${PROJECT}-${BRANCH}" \
                    | tr '[:upper:]_ ', '[:lower:]--' \
                    | cut -c 1-63 \
                    | sed 's/\(.*\)-$/\1/')

kubectl --kubeconfig ${KUBE_CONFIG} -n ${NAMESPACE} \
  delete vs ${BKWI_SERVICE_NAME}-vs

kubectl --kubeconfig ${KUBE_CONFIG} -n ${NAMESPACE} \
  delete svc ${BKWI_SERVICE_NAME}

kubectl --kubeconfig ${KUBE_CONFIG} -n ${NAMESPACE} \
  delete deploy ${BKWI_SERVICE_NAME}
